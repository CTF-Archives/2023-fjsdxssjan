ALTER TABLE `zt_im_message` ADD `deleted` enum('0','1') COLLATE 'utf8_general_ci' NOT NULL;
