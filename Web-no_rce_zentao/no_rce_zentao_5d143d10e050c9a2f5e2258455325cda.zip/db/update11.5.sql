ALTER TABLE `zt_entry` ADD `freePasswd` enum('0','1') NOT NULL DEFAULT '0' AFTER `key`;
