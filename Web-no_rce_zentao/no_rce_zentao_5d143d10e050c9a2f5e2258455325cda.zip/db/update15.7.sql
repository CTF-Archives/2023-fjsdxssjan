ALTER TABLE `zt_apistruct` MODIFY COLUMN `desc` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `type`;
