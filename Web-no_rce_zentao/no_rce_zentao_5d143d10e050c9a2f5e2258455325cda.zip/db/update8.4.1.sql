ALTER TABLE `zt_file` CHANGE `size` `size` int unsigned NOT NULL DEFAULT '0' AFTER `extension`;
