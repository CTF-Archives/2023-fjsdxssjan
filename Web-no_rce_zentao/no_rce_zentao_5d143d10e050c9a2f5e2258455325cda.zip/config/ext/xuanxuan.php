<?php
$config->openMethods[] = 'setting.downloadxxd';
