ALTER TABLE `zt_im_chatuser` ADD `lastReadMessage` int(11) unsigned NOT NULL DEFAULT 0 AFTER `category`;
