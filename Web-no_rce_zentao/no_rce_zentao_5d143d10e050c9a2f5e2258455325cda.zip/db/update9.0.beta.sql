ALTER TABLE `zt_burn` ADD `estimate` float NOT NULL AFTER `date`;
