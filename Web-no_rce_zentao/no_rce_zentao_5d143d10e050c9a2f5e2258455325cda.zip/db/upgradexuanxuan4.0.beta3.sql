ALTER TABLE `zt_im_message` DROP COLUMN `order`;
ALTER TABLE `zt_im_message_backup` DROP COLUMN `order`;
