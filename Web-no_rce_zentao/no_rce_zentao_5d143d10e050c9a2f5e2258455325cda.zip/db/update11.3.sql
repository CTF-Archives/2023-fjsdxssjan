ALTER TABLE `zt_case` ADD `fromCaseVersion` mediumint(8) unsigned NOT NULL default '1' AFTER `fromCaseID`;
