ALTER TABLE `zt_im_client` CHANGE `version` `version` char(30) NOT NULL DEFAULT '';
